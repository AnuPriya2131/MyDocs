Configuration ContosoWebsite
{

  Node localhost
  {
    #Install the IIS Role
      WindowsFeature InstallIIS {
            Name = "Web-Server"
            Ensure = "Present"
        }

    #Install ASP.NET 4.5
   

   
  }
} 
ContosoWebsite